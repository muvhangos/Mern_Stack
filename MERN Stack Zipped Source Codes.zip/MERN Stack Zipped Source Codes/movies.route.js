const express = require("express");

const MoviesController = require("../controller/moviesController");
const ReviewsController = require("../reviews/reviews.controller");

const router = express.Router();

// Get all movies
router.route("/")
    .get(MoviesController.apiGetMovies);

// Reviews
router.route("/review")
    .post(ReviewsController.apiPostReview)
    .put(ReviewsController.apiUpdateReview)
    .delete(ReviewsController.apiDeleteReview);

// Get a single movie
router.route("/:id")
    .get(MoviesController.apiGetMovieById);

module.exports = router;