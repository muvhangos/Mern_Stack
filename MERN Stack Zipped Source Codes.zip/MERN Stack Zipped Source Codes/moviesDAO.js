const { ObjectId } = require("mongodb");

let moviesCollection;

async function injectDB(conn) {
    if (moviesCollection) {
        return;
    }

    try {
        const db = conn.db(process.env.MONGODB_DB_NAME);
        moviesCollection = db.collection("movies");

        console.log("Movies collection connected");
    } catch (error) {
        console.error("Unable to establish movies collection:", error);
    }
}

async function getMovies() {
    try {
        return await moviesCollection
            .find({})
            .limit(10)
            .toArray();
    } catch (error) {
        console.error("Unable to get movies:", error);
        return [];
    }
}

async function getMovieById(movieId) {
    try {
        return await moviesCollection.findOne({
            _id: new ObjectId(movieId)
        });
    } catch (error) {
        console.error("Unable to get movie by ID:", error);
        return null;
    }
}

module.exports = {
    injectDB,
    getMovies,
    getMovieById
};