require("dotenv").config();

const express = require("express");
const { MongoClient } = require("mongodb");
const moviesDAO = require("./dao/moviesDAO");
const moviesController = require("./controller/moviesController");

const app = express();
const PORT = 3002;

const client = new MongoClient(process.env.MONGODB_URI);

app.use(express.json());

async function startServer() {
    try {
        await client.connect();

        console.log("Connected to MongoDB Atlas");

        await moviesDAO.injectDB(client);

        app.get("/", (req, res) => {
            res.send("Chapter 8 Movies API is running");
        });

        app.get("/api/movies", moviesController.apiGetMovies);

        app.listen(PORT, () => {
            console.log(`Server running at http://localhost:${PORT}`);
        });
    } catch (error) {
        console.error("Server startup failed:", error.message);
    }
}

startServer();
