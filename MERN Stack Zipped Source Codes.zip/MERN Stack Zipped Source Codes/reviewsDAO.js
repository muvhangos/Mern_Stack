const { ObjectId } = require("mongodb");

let commentsCollection;

async function injectDB(conn) {
    if (commentsCollection) {
        return;
    }

    try {
        const db = conn.db(process.env.MONGODB_DB_NAME);
        commentsCollection = db.collection("comments");

        console.log("Comments collection connected");
    } catch (error) {
        console.error("Unable to connect to comments collection:", error);
        throw error;
    }
}

async function addReview(movieId, userInfo, review, date) {
    try {
        const reviewDoc = {
            name: userInfo.name,
            email: userInfo.email,
            movie_id: movieId,
            text: review,
            date: date
        };

        return await commentsCollection.insertOne(reviewDoc);
    } catch (error) {
        return { error: error.message };
    }
}

async function updateReview(reviewId, email, review, date) {
    try {
        const result = await commentsCollection.updateOne(
            {
                _id: new ObjectId(reviewId),
                email: email
            },
            {
                $set: {
                    text: review,
                    date: date
                }
            }
        );

        return result;
    } catch (error) {
        return { error: error.message };
    }
}

async function deleteReview(reviewId, email) {
    try {
        const result = await commentsCollection.deleteOne({
            _id: new ObjectId(reviewId),
            email: email
        });

        return result;
    } catch (error) {
        return { error: error.message };
    }
}

async function getReviewsByMovieId(movieId) {
    try {
        return await commentsCollection
            .find({ movie_id: movieId })
            .sort({ date: -1 })
            .toArray();
    } catch (error) {
        console.error("Unable to get reviews:", error);
        return [];
    }
}

module.exports = {
    injectDB,
    addReview,
    updateReview,
    deleteReview,
    getReviewsByMovieId
};