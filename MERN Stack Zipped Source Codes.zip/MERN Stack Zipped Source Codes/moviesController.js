const moviesDAO = require("../dao/moviesDAO");

async function apiGetMovies(req, res) {
    try {
        const movies = await moviesDAO.getMovies();
        res.json(movies);
    } catch (error) {
        console.error("Unable to get movies:", error);
        res.status(500).json({ error: error.message });
    }
}

module.exports = {
    apiGetMovies
};