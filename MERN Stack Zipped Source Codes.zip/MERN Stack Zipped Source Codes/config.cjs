require('./index.cjs').config()
