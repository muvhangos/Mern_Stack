const ReviewsDAO = require("../dao/reviewsDAO");

class ReviewsController {

    static async apiPostReview(req, res, next) {
        try {
            const movieId = req.body.movie_id;
            const review = req.body.review;

            const userInfo = {
                name: req.body.name,
                email: req.body.email
            };

            const date = new Date();

            const ReviewResponse = await ReviewsDAO.addReview(
                movieId,
                userInfo,
                review,
                date
            );

            if (ReviewResponse.error) {
                return res.status(500).json({
                    error: ReviewResponse.error
                });
            }

            res.json({
                status: "success",
                insertedId: ReviewResponse.insertedId
            });

        } catch (e) {
            res.status(500).json({
                error: e.message
            });
        }
    }

    static async apiUpdateReview(req, res, next) {
        try {
            const reviewId = req.body.review_id;
            const review = req.body.review;
            const email = req.body.email;
            const date = new Date();

            const ReviewResponse = await ReviewsDAO.updateReview(
                reviewId,
                email,
                review,
                date
            );

            if (ReviewResponse.error) {
                return res.status(500).json({
                    error: ReviewResponse.error
                });
            }

            if (ReviewResponse.modifiedCount === 0) {
                return res.status(404).json({
                    error: "Unable to update review. Review not found."
                });
            }

            res.json({
                status: "success"
            });

        } catch (e) {
            res.status(500).json({
                error: e.message
            });
        }
    }

    static async apiDeleteReview(req, res, next) {
        try {
            const reviewId = req.body.review_id;
            const email = req.body.email;

            const ReviewResponse = await ReviewsDAO.deleteReview(
                reviewId,
                email
            );

            if (ReviewResponse.error) {
                return res.status(500).json({
                    error: ReviewResponse.error
                });
            }

            if (ReviewResponse.deletedCount === 0) {
                return res.status(404).json({
                    error: "Unable to delete review. Review not found."
                });
            }

            res.json({
                status: "success"
            });

        } catch (e) {
            res.status(500).json({
                error: e.message
            });
        }
    }
}

module.exports = ReviewsController;